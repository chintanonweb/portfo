
<title><?php echo $heading; ?> | Portfo-A Portfolio Cloud</title>
<!-- Meta -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="x-ua-compatible" content="ie=edge">

<!-- Favicon -->
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">

<!-- Web Fonts -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

<!-- Components Vendor Styles -->
<link rel="stylesheet" href="/panelassets/vendor/font-awesome/css/all.min.css">
<link rel="stylesheet" href="/panelassets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="/panelassets/css/style.css">


<!-- Theme Styles -->
<link rel="stylesheet" href="/panelassets/css/theme.css">
<link rel="stylesheet" href="/panelassets/css/custom.css">
<!-- Custom Charts -->
<style>
.js-doughnut-chart {
    width: 70px !important;
    height: 70px !important;
}
</style>