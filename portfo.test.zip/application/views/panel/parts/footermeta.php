<script src="/panelassets/vendor/jquery/dist/jquery.min.js"></script> 
<script src="/panelassets/vendor/jquery-migrate/jquery-migrate.min.js"></script>
<script src="/panelassets/vendor/popper.js/dist/umd/popper.min.js"></script>
<script src="/panelassets/vendor/bootstrap/bootstrap.min.js"></script>

<!-- Plugins -->
<script src="/panelassets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="/panelassets/vendor/chart.js/dist/Chart.min.js"></script>

<!-- Initialization  -->
<script src="/panelassets/js/sidebar-nav.js"></script>
<script src="/panelassets/js/main.js"></script>
<script src="/panelassets/js/dashboard-page-scripts.js"></script>


