<footer class="u-footer d-md-flex align-items-md-center text-center text-md-left text-muted text-muted">
    <p class="h5 mb-2 mb-md-0"> <a class="link-muted" href="" target="_blank"></a></p>

    <p class="h5 mb-0 ml-auto">
        &copy; 2019 <a class="link-muted" href="" target="_blank">Portfo - A Portfolio Cloud</a>
    </p>
</footer>