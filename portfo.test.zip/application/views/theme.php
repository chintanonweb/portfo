<?php 
echo $username;
?>